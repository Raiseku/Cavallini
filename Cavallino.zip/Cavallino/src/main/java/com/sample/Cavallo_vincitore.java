package com.sample;

public class Cavallo_vincitore {

	public String seme_vincitore;
	
	public Cavallo_vincitore(String seme_vincitore) {
		this.seme_vincitore = seme_vincitore;
	}

	public String getSeme_vincitore() {
		return seme_vincitore;
	}

	public void setSeme_vincitore(String seme_vincitore) {
		this.seme_vincitore = seme_vincitore;
	}

	
	
}
